import pymongo
from bson.objectid import ObjectId
import random

# Conectar a MongoDB (ejemplo: corriendo en Docker)
client = pymongo.MongoClient("mongodb://localhost:27017/?replicaSet=rs0")

db = client["cine_db"]  # Nombre de la base de datos

# --- 1. Colección de Directores ---

db.directors.delete_many({})

directors_data = [

    {"name": "Christopher Nolan", "nationality": "UK", "birth_date": "1970-07-30", "awards": 34},

    {"name": "Steven Spielberg", "nationality": "USA", "birth_date": "1946-12-18", "awards": 50},

    {"name": "Quentin Tarantino", "nationality": "USA", "birth_date": "1963-03-27", "awards": 20},

    {"name": "Martin Scorsese", "nationality": "USA", "birth_date": "1942-11-17", "awards": 45},

    {"name": "James Cameron", "nationality": "Canada", "birth_date": "1954-08-16", "awards": 28},

    {"name": "Hayao Miyazaki", "nationality": "Japan", "birth_date": "1941-01-05", "awards": 20},

    {"name": "Peter Jackson", "nationality": "New Zealand", "birth_date": "1961-10-31", "awards": 25},

    {"name": "Ridley Scott", "nationality": "UK", "birth_date": "1937-11-30", "awards": 15},

    {"name": "David Fincher", "nationality": "USA", "birth_date": "1962-08-28", "awards": 18},

    {"name": "Alfonso Cuarón", "nationality": "Mexico", "birth_date": "1961-11-28", "awards": 22},

    {"name": "Wes Anderson", "nationality": "USA", "birth_date": "1969-05-01", "awards": 10},

    {"name": "Guillermo del Toro", "nationality": "Mexico", "birth_date": "1964-10-09", "awards": 15},

    {"name": "Tim Burton", "nationality": "USA", "birth_date": "1958-08-25", "awards": 12},

    {"name": "Joel Coen", "nationality": "USA", "birth_date": "1954-11-29", "awards": 18},

    {"name": "Ethan Coen", "nationality": "USA", "birth_date": "1957-09-21", "awards": 18},

    {"name": "George Lucas", "nationality": "USA", "birth_date": "1944-05-14", "awards": 12},

    {"name": "James Wan", "nationality": "Australia", "birth_date": "1977-02-26", "awards": 8},

    {"name": "Clint Eastwood", "nationality": "USA", "birth_date": "1930-05-31", "awards": 35},

    {"name": "Ron Howard", "nationality": "USA", "birth_date": "1954-03-01", "awards": 20},

    {"name": "Spike Lee", "nationality": "USA", "birth_date": "1957-03-20", "awards": 15},

    {"name": "Sofia Coppola", "nationality": "USA", "birth_date": "1971-05-14", "awards": 10},

    {"name": "Akira Kurosawa", "nationality": "Japan", "birth_date": "1910-03-23", "awards": 25},

    {"name": "Stanley Kubrick", "nationality": "USA", "birth_date": "1928-07-26", "awards": 20},

    {"name": "Richard Linklater", "nationality": "USA", "birth_date": "1960-07-30", "awards": 12},

    {"name": "James L. Brooks", "nationality": "USA", "birth_date": "1940-12-09", "awards": 15},

    {"name": "Woody Allen", "nationality": "USA", "birth_date": "1935-12-01", "awards": 25},

    {"name": "Frank Darabont", "nationality": "USA", "birth_date": "1959-01-28", "awards": 12},

    {"name": "Ang Lee", "nationality": "Taiwan", "birth_date": "1954-10-23", "awards": 20},

    {"name": "Danny Boyle", "nationality": "UK", "birth_date": "1956-10-20", "awards": 18},

    {"name": "Jordan Peele", "nationality": "USA", "birth_date": "1979-02-21", "awards": 8}

]

director_ids = []

for d in directors_data:

    result = db.directors.insert_one(d)

    director_ids.append({"_id": result.inserted_id, "name": d["name"]})

print("-> 30 directors inserted.")
client.close()