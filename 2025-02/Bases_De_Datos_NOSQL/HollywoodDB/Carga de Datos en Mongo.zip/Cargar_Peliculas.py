import pymongo
from bson.objectid import ObjectId
import random

# Conectar a MongoDB (ejemplo: corriendo en Docker)
client = pymongo.MongoClient("mongodb://localhost:27017/?replicaSet=rs0")
db = client["cine_db"]  # Nombre de la base de datos

# --- AÑADIDO: OBTENER LOS DIRECTORES ---
# Primero, necesitamos los IDs de los directores que ya están en la BD
directors_from_db = list(db.directors.find())
director_ids = [{"_id": d["_id"], "name": d["name"]} for d in directors_from_db]
print(f"-> Encontrados {len(director_ids)} directores en la BD para vincular.")
# --- FIN DE AÑADIDO ---


# --- 2. Colección de Películas ---
db.peliculas.delete_many({})

movies_data = [
    {"title": "Inception", "genre": "Sci-Fi", "year": 2010, "duration": 148, "director_name": "Christopher Nolan", "language": "English", "country": "USA"},
    {"title": "Interstellar", "genre": "Sci-Fi", "year": 2014, "duration": 169, "director_name": "Christopher Nolan", "language": "English", "country": "USA"},
    {"title": "Dunkirk", "genre": "War", "year": 2017, "duration": 106, "director_name": "Christopher Nolan", "language": "English", "country": "UK"},
    {"title": "Jurassic Park", "genre": "Adventure", "year": 1993, "duration": 127, "director_name": "Steven Spielberg", "language": "English", "country": "USA"},
    {"title": "Schindler's List", "genre": "Drama", "year": 1993, "duration": 195, "director_name": "Steven Spielberg", "language": "English", "country": "USA"},
    {"title": "Pulp Fiction", "genre": "Crime", "year": 1994, "duration": 154, "director_name": "Quentin Tarantino", "language": "English", "country": "USA"},
    {"title": "Kill Bill: Vol. 1", "genre": "Action", "year": 2003, "duration": 111, "director_name": "Quentin Tarantino", "language": "English", "country": "USA"},
    {"title": "Avatar", "genre": "Sci-Fi", "year": 2009, "duration": 162, "director_name": "James Cameron", "language": "English", "country": "USA"},
    {"title": "Titanic", "genre": "Romance", "year": 1997, "duration": 195, "director_name": "James Cameron", "language": "English", "country": "USA"},
    {"title": "Spirited Away", "genre": "Animation", "year": 2001, "duration": 125, "director_name": "Hayao Miyazaki", "language": "Japanese", "country": "Japan"},
    {"title": "My Neighbor Totoro", "genre": "Animation", "year": 1988, "duration": 86, "director_name": "Hayao Miyazaki", "language": "Japanese", "country": "Japan"},
    {"title": "The Lord of the Rings: The Fellowship of the Ring", "genre": "Fantasy", "year": 2001, "duration": 178, "director_name": "Peter Jackson", "language": "English", "country": "New Zealand"},
    {"title": "The Lord of the Rings: The Two Towers", "genre": "Fantasy", "year": 2002, "duration": 179, "director_name": "Peter Jackson", "language": "English", "country": "New Zealand"},
    {"title": "The Lord of the Rings: The Return of the King", "genre": "Fantasy", "year": 2003, "duration": 201, "director_name": "Peter Jackson", "language": "English", "country": "New Zealand"},
    {"title": "Gladiator", "genre": "Action", "year": 2000, "duration": 155, "director_name": "Ridley Scott", "language": "English", "country": "UK"},
    {"title": "Alien", "genre": "Sci-Fi", "year": 1979, "duration": 117, "director_name": "Ridley Scott", "language": "English", "country": "UK"},
    {"title": "Fight Club", "genre": "Drama", "year": 1999, "duration": 139, "director_name": "David Fincher", "language": "English", "country": "USA"},
    {"title": "Se7en", "genre": "Crime", "year": 1995, "duration": 127, "director_name": "David Fincher", "language": "English", "country": "USA"},
    {"title": "Gravity", "genre": "Sci-Fi", "year": 2013, "duration": 91, "director_name": "Alfonso Cuarón", "language": "English", "country": "USA"},
    {"title": "Roma", "genre": "Drama", "year": 2018, "duration": 135, "director_name": "Alfonso Cuarón", "language": "Spanish", "country": "Mexico"},
    {"title": "The Grand Budapest Hotel", "genre": "Comedy", "year": 2014, "duration": 99, "director_name": "Wes Anderson", "language": "English", "country": "USA"},
    {"title": "Pan's Labyrinth", "genre": "Fantasy", "year": 2006, "duration": 118, "director_name": "Guillermo del Toro", "language": "Spanish", "country": "Mexico"},
    {"title": "The Shape of Water", "genre": "Romance", "year": 2017, "duration": 123, "director_name": "Guillermo del Toro", "language": "English", "country": "USA"},
    {"title": "Edward Scissorhands", "genre": "Fantasy", "year": 1990, "duration": 105, "director_name": "Tim Burton", "language": "English", "country": "USA"},
    {"title": "No Country for Old Men", "genre": "Crime", "year": 2007, "duration": 122, "director_name": "Joel Coen", "language": "English", "country": "USA"},
    {"title": "Fargo", "genre": "Crime", "year": 1996, "duration": 98, "director_name": "Joel Coen", "language": "English", "country": "USA"},
    {"title": "Star Wars: Episode IV - A New Hope", "genre": "Sci-Fi", "year": 1977, "duration": 121, "director_name": "George Lucas", "language": "English", "country": "USA"},
    {"title": "The Conjuring", "genre": "Horror", "year": 2013, "duration": 112, "director_name": "James Wan", "language": "English", "country": "USA"},
    {"title": "Unforgiven", "genre": "Western", "year": 1992, "duration": 131, "director_name": "Clint Eastwood", "language": "English", "country": "USA"},
    {"title": "A Beautiful Mind", "genre": "Drama", "year": 2001, "duration": 135, "director_name": "Ron Howard", "language": "English", "country": "USA"},
    {"title": "Do the Right Thing", "genre": "Drama", "year": 1989, "duration": 120, "director_name": "Spike Lee", "language": "English", "country": "USA"},
    {"title": "Lost in Translation", "genre": "Drama", "year": 2003, "duration": 102, "director_name": "Sofia Coppola", "language": "English", "country": "USA"},
    {"title": "Seven Samurai", "genre": "Action", "year": 1954, "duration": 207, "director_name": "Akira Kurosawa", "language": "Japanese", "country": "Japan"},
    {"title": "2001: A Space Odyssey", "genre": "Sci-Fi", "year": 1968, "duration": 149, "director_name": "Stanley Kubrick", "language": "English", "country": "UK"},
    {"title": "Boyhood", "genre": "Drama", "year": 2014, "duration": 165, "director_name": "Richard Linklater", "language": "English", "country": "USA"},
    {"title": "Terms of Endearment", "genre": "Drama", "year": 1983, "duration": 132, "director_name": "James L. Brooks", "language": "English", "country": "USA"},
    {"title": "Annie Hall", "genre": "Romance", "year": 1977, "duration": 93, "director_name": "Woody Allen", "language": "English", "country": "USA"},
    {"title": "The Shawshank Redemption", "genre": "Drama", "year": 1994, "duration": 142, "director_name": "Frank Darabont", "language": "English", "country": "USA"},
    {"title": "Crouching Tiger, Hidden Dragon", "genre": "Action", "year": 2000, "duration": 120, "director_name": "Ang Lee", "language": "Mandarin", "country": "Taiwan"},
    {"title": "Slumdog Millionaire", "genre": "Drama", "year": 2008, "duration": 120, "director_name": "Danny Boyle", "language": "English", "country": "UK"},
    {"title": "Get Out", "genre": "Horror", "year": 2017, "duration": 104, "director_name": "Jordan Peele", "language": "English", "country": "USA"}
]

peliculas = []
peliculas_insertadas = 0
for m in movies_data:
    # --- AÑADIDO: LÓGICA DE BÚSQUEDA ---
    director = next((d for d in director_ids if d["name"] == m["director_name"]), None)
    
    if director:
    # --- FIN DE AÑADIDO ---
        peliculas.append({
            "title": m["title"],
            "genre": m["genre"],
            "year": m["year"],
            "duration": m["duration"],
            "director_id": director["_id"],  # Ahora 'director' sí existe
            "director_name": director["name"], # Ahora 'director' sí existe
            "rating": round(random.uniform(7.0, 9.5), 1),
            "box_office_millions": round(random.uniform(100.0, 2500.0), 2),
            "language": m["language"],
            "country": m["country"]
        })
        peliculas_insertadas += 1
    else:
        # Esto te avisará si falta un director
        print(f"ADVERTENCIA: No se encontró el director '{m['director_name']}' para la película '{m['title']}'")


if peliculas:
    db.peliculas.insert_many(peliculas)
    print(f"-> {peliculas_insertadas} películas insertadas.")
else:
    print("-> No se insertaron películas (quizás no se encontraron directores).")

client.close()