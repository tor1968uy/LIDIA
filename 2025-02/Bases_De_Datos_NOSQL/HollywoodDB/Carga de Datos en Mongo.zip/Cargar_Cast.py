import pymongo
from bson.objectid import ObjectId
import random

# Conectar a MongoDB (ejemplo: corriendo en Docker)
client = pymongo.MongoClient("mongodb://localhost:27017/?replicaSet=rs0")

db = client["cine_db"]  # Nombre de la base de datos



# --- 3. Colección de Reparto ---

db.cast.delete_many({})

actors_data = [

    {"name": "Leonardo DiCaprio"}, 
    {"name": "Joseph Gordon-Levitt"}, 
    {"name": "Elliot Page"},
    {"name": "Matthew McConaughey"}, 
    {"name": "Anne Hathaway"}, 
    {"name": "Tom Hardy"},
    {"name": "Sam Neill"}, 
    {"name": "Laura Dern"}, 
    {"name": "Jeff Goldblum"},
    {"name": "John Travolta"}, 
    {"name": "Uma Thurman"}, 
    {"name": "Samuel L. Jackson"},
    {"name": "Marlon Brando"}, 
    {"name": "Al Pacino"}, 
    {"name": "Keanu Reeves"},
    {"name": "Kate Winslet"}, 
    {"name": "Peter Jackson"}, 
    {"name": "Elijah Wood"}, 
    {"name": "Ian McKellen"},
    {"name": "Russell Crowe"}, 
    {"name": "Joaquin Phoenix"}, 
    {"name": "Sigourney Weaver"},
    {"name": "Brad Pitt"}, 
    {"name": "Morgan Freeman"}, 
    {"name": "Sandra Bullock"},
    {"name": "George Clooney"}, 
    {"name": "Daniel Day-Lewis"}, 
    {"name": "Scarlett Johansson"},
    {"name": "Tom Hanks"}, 
    {"name": "Dev Patel"}, 
    {"name": "Daniel Craig"}, 
    {"name": "Chris Pratt"},
    {"name": "Gal Gadot"}, 
    {"name": "Zoe Saldana"}, 
    {"name": "Harrison Ford"}, 
    {"name": "Mark Hamill"},
    {"name": "Carrie Fisher"}, 
    {"name": "Jordan Peele"}, 
    {"name": "Emma Stone"}, 
    {"name": "Ryan Gosling"}

]



db_cast = []

pelicula_ids = [p["_id"] for p in db.peliculas.find()]



for pid in pelicula_ids:

    

    selected_actors = random.sample(actors_data, random.randint(1, 5))  

    for actor in selected_actors:

        db_cast.append({

            "movie_id": pid,

            "actor_name": actor["name"],

            "role": random.choice(["Protagonist", "Supporting", "Cameo"]),

            "salary_millions": round(random.uniform(0.2, 20.0), 2)

        })



db.cast.insert_many(db_cast)

client.close()