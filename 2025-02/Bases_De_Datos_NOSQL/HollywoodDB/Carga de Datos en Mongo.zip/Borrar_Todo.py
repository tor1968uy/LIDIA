import pymongo
from bson.objectid import ObjectId
import random

# Conectar a MongoDB (ejemplo: corriendo en Docker)
client = pymongo.MongoClient("mongodb://localhost:27017/?replicaSet=rs0")

db = client["cine_db"]  # Nombre de la base de datos

# --- 1. Colección de Directores ---
db.cast.delete_many({})
db.peliculas.delete_many({})
db.directors.delete_many({})
client.close()